import SwiftUI

/// YourDisk의 앱 생명 주기와 메뉴 막대 진입점을 구성합니다.
@main
@MainActor
struct YourDiskApp: App {
    @State private var viewModel = YourDiskViewModel()

    var body: some Scene {
        MenuBarExtra {
            StorageMenuView(viewModel: viewModel)
        } label: {
            Image(systemName: "internaldrive.fill")
                .accessibilityLabel("YourDisk")
        }
        .menuBarExtraStyle(.window)
    }
}
