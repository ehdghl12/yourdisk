import AppKit
import Foundation

/// Finder 열기와 안전한 볼륨 추출 동작을 제공하는 계약입니다.
protocol VolumeActionProviding: Sendable {
    /// Finder에서 지정한 볼륨의 루트 폴더를 엽니다.
    @MainActor
    func revealVolume(at url: URL) throws

    /// 지정한 외장 볼륨을 강제 처리 없이 안전하게 추출합니다.
    func ejectVolume(at url: URL) async throws
}

/// Finder가 볼륨 열기 요청을 처리하지 못했을 때 발생하는 오류입니다.
enum VolumeActionError: LocalizedError, Sendable {
    case unableToRevealVolume

    var errorDescription: String? {
        switch self {
        case .unableToRevealVolume:
            return "Unable to open this volume."
        }
    }
}

/// NSWorkspace를 사용해 외장 볼륨 동작을 수행합니다.
struct WorkspaceVolumeActionService: VolumeActionProviding {
    /// Finder에서 지정한 볼륨의 루트 폴더를 엽니다.
    @MainActor
    func revealVolume(at url: URL) throws {
        let resolvedURL = url
            .resolvingSymlinksInPath()
            .standardizedFileURL

        guard FileManager.default.fileExists(atPath: resolvedURL.path) else {
            throw VolumeActionError.unableToRevealVolume
        }

        let didOpen = NSWorkspace.shared.open(resolvedURL)

        guard didOpen else {
            throw VolumeActionError.unableToRevealVolume
        }
    }

    /// NSWorkspace의 동기식 안전 추출을 UI 밖의 작업에서 실행합니다.
    func ejectVolume(at url: URL) async throws {
        let resolvedURL = url
            .resolvingSymlinksInPath()
            .standardizedFileURL

        try await Task.detached(priority: .userInitiated) {
            try NSWorkspace.shared.unmountAndEjectDevice(at: resolvedURL)
        }.value
    }
}
