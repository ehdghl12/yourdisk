import AppKit

/// 메뉴가 표시되는 동안 macOS 볼륨 연결 상태 변경을 전달합니다.
@MainActor
final class WorkspaceVolumeObserver: NSObject {
    private let notificationCenter: NotificationCenter
    private var onVolumeChange: (() -> Void)?
    private var isObserving = false

    /// NSWorkspace 전용 notification center를 사용하는 observer를 생성합니다.
    override init() {
        notificationCenter = NSWorkspace.shared.notificationCenter
        super.init()
    }

    /// 마운트, 마운트 해제, 볼륨 이름 변경 알림 구독을 시작합니다.
    func start(onVolumeChange: @escaping () -> Void) {
        guard !isObserving else { return }

        self.onVolumeChange = onVolumeChange
        let notificationNames: [Notification.Name] = [
            NSWorkspace.didMountNotification,
            NSWorkspace.didUnmountNotification,
            NSWorkspace.didRenameVolumeNotification
        ]

        for name in notificationNames {
            notificationCenter.addObserver(
                self,
                selector: #selector(handleVolumeChange(_:)),
                name: name,
                object: nil
            )
        }
        isObserving = true
    }

    /// 등록된 모든 볼륨 알림을 해제하고 콜백 참조를 정리합니다.
    func stop() {
        guard isObserving else {
            onVolumeChange = nil
            return
        }

        notificationCenter.removeObserver(self)
        onVolumeChange = nil
        isObserving = false
    }

    /// NSWorkspace 알림을 등록된 갱신 콜백으로 전달합니다.
    @objc
    private func handleVolumeChange(_ notification: Notification) {
        onVolumeChange?()
    }

    deinit {
        notificationCenter.removeObserver(self)
    }
}
