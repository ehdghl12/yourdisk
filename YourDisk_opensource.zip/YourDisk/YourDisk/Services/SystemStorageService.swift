import Foundation
import OSLog

/// 현재 시스템의 저장공간 스냅샷을 제공하는 타입의 계약입니다.
protocol StorageVolumeProviding: Sendable {
    /// 시스템 볼륨과 연결된 외장 볼륨을 새로 조회합니다.
    func fetchStorageReport() async throws -> StorageReport
}

/// 저장공간 정보를 읽을 수 없을 때 발생하는 오류입니다.
enum StorageServiceError: LocalizedError {
    case capacityUnavailable(URL)

    var errorDescription: String? {
        switch self {
        case let .capacityUnavailable(url):
            return "Storage information is unavailable for \(url.path)."
        }
    }
}

/// Foundation API를 사용해 로컬 시스템과 외장 볼륨을 조회합니다.
struct SystemStorageService: StorageVolumeProviding {
    private static let logger = Logger(
        subsystem: "com.ehdghl.yourdisk",
        category: "Storage"
    )

    private static let resourceKeys: Set<URLResourceKey> = [
        .volumeNameKey,
        .volumeTotalCapacityKey,
        .volumeAvailableCapacityKey,
        .volumeAvailableCapacityForImportantUsageKey,
        .volumeAvailableCapacityForOpportunisticUsageKey,
        .volumeIsInternalKey,
        .volumeIsRemovableKey,
        .volumeIsEjectableKey,
        .volumeIsLocalKey
    ]

    /// 파일 시스템 조회를 utility 우선순위 작업에서 한 번 실행합니다.
    func fetchStorageReport() async throws -> StorageReport {
        try await Task.detached(priority: .utility) {
            try Self.readStorageReport()
        }.value
    }

    /// 시스템 볼륨과 현재 연결된 로컬 외장 볼륨을 읽습니다.
    private static func readStorageReport() throws -> StorageReport {
        let systemURL = URL(fileURLWithPath: "/", isDirectory: true)
        let systemValues = try systemURL.resourceValues(forKeys: resourceKeys)
        let systemVolume = try makeVolume(
            at: systemURL,
            values: systemValues,
            isEjectable: false
        )

        let mountedURLs = FileManager.default.mountedVolumeURLs(
            includingResourceValuesForKeys: Array(resourceKeys),
            options: [.skipHiddenVolumes]
        ) ?? []

        var visitedURLs = Set<URL>()
        let externalVolumes = mountedURLs.compactMap { url -> StorageVolume? in
            let normalizedURL = url.resolvingSymlinksInPath().standardizedFileURL
            guard normalizedURL.path != systemURL.path,
                  visitedURLs.insert(normalizedURL).inserted,
                  let values = try? normalizedURL.resourceValues(forKeys: resourceKeys),
                  isExternalLocalVolume(at: normalizedURL, values: values),
                  let volume = try? makeVolume(
                      at: normalizedURL,
                      values: values,
                      isEjectable: true
                  ) else {
                return nil
            }
            return volume
        }
        .sorted {
            $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }

        return StorageReport(
            systemVolume: systemVolume,
            externalVolumes: externalVolumes,
            refreshedAt: Date()
        )
    }

    /// 리소스 값을 UI에서 사용할 수 있는 불변 볼륨 모델로 변환합니다.
    private static func makeVolume(
        at url: URL,
        values: URLResourceValues,
        isEjectable: Bool
    ) throws -> StorageVolume {
        guard let totalCapacity = values.volumeTotalCapacity.map(Int64.init),
              totalCapacity > 0 else {
            throw StorageServiceError.capacityUnavailable(url)
        }

        guard let availableCapacity = availableCapacity(from: values, at: url) else {
            throw StorageServiceError.capacityUnavailable(url)
        }

        let fallbackName = url.lastPathComponent.isEmpty ? "System Disk" : url.lastPathComponent
        let volumeName = values.volumeName?.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = volumeName.flatMap { $0.isEmpty ? nil : $0 } ?? fallbackName

        return StorageVolume(
            id: url,
            name: name,
            mountURL: url,
            totalCapacity: totalCapacity,
            availableCapacity: max(min(availableCapacity, totalCapacity), 0),
            isEjectable: isEjectable
        )
    }

    /// 여러 파일 시스템에서 달라질 수 있는 가용 용량 key를 순서대로 해석합니다.
    private static func availableCapacity(
        from values: URLResourceValues,
        at url: URL
    ) -> Int64? {
        let important = values.volumeAvailableCapacityForImportantUsage
        let standard = values.volumeAvailableCapacity.map(Int64.init)
        let opportunistic = values.volumeAvailableCapacityForOpportunisticUsage

        if let important, important > 0 {
            return important
        }

        if let standard, standard > 0 {
            logger.debug(
                "Using standard available capacity fallback for \(url.path, privacy: .public)."
            )
            return standard
        }

        if let opportunistic, opportunistic > 0 {
            logger.debug(
                "Using opportunistic available capacity fallback for \(url.path, privacy: .public)."
            )
            return opportunistic
        }

        if important == 0 || standard == 0 || opportunistic == 0 {
            logger.debug(
                "Available capacity resolved to zero for \(url.path, privacy: .public)."
            )
            logger.debug(
                "Important capacity value: \(important ?? -1)."
            )
            logger.debug(
                "Standard capacity value: \(standard ?? -1)."
            )
            logger.debug(
                "Opportunistic capacity value: \(opportunistic ?? -1)."
            )
            return 0
        }

        logger.error(
            "All available capacity keys are unavailable for \(url.path, privacy: .public)."
        )
        return nil
    }

    /// 시스템 내부 볼륨을 제외한 로컬 외장 장치인지 판별합니다.
    private static func isExternalLocalVolume(
        at url: URL,
        values: URLResourceValues
    ) -> Bool {
        guard values.volumeIsLocal != false else { return false }

        let isMountedUnderVolumes = url.path.hasPrefix("/Volumes/")
        return values.volumeIsRemovable == true
            || values.volumeIsInternal == false
            || isMountedUnderVolumes
    }
}
