import AppKit
import Foundation

/// YourDisk 메뉴에서 사용하는 macOS 시스템 동작을 제공합니다.
@MainActor
enum SystemNavigation {
    /// 시스템에 설치된 Disk Utility 애플리케이션을 엽니다.
    static func openDiskUtility() {
        guard let applicationURL = NSWorkspace.shared.urlForApplication(
            withBundleIdentifier: "com.apple.DiskUtility"
        ) else {
            return
        }

        NSWorkspace.shared.openApplication(
            at: applicationURL,
            configuration: NSWorkspace.OpenConfiguration(),
            completionHandler: nil
        )
    }

    /// System Settings의 Storage 화면을 엽니다.
    static func openStorageSettings() {
        guard let settingsURL = URL(
            string: "x-apple.systempreferences:com.apple.settings.Storage"
        ) else {
            return
        }
        NSWorkspace.shared.open(settingsURL)
    }

    /// 현재 YourDisk 프로세스를 정상 종료합니다.
    static func quitApplication() {
        NSApplication.shared.terminate(nil)
    }
}
