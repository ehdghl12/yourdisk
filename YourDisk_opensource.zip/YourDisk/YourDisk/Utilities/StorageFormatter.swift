import Foundation

/// 저장공간과 갱신 시간을 시스템 로케일에 맞게 표시합니다.
enum StorageFormatter {
    /// 바이트 값을 Finder와 같은 파일 용량 단위로 변환합니다.
    static func capacity(_ byteCount: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: byteCount, countStyle: .file)
    }

    /// 0부터 1 사이의 비율을 반올림한 백분율로 변환합니다.
    static func percentage(_ fraction: Double) -> String {
        let clampedFraction = min(max(fraction, 0), 1)
        return "\(Int((clampedFraction * 100).rounded()))%"
    }
}
