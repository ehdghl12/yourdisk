import AppKit
import SwiftUI

/// Apple 시스템 메뉴와 유사한 계층으로 저장공간 정보를 표시합니다.
struct StorageMenuView: View {
    @Bindable var viewModel: YourDiskViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            storageSection
            sectionDivider
            diskInformationSection
            sectionDivider
            connectedStorageSection
            sectionDivider
            actionsSection
        }
        .padding(14)
        .frame(width: 320)
        .onAppear {
            viewModel.startObservingVolumeChanges()
        }
        .onDisappear {
            viewModel.stopObservingVolumeChanges()
        }
    }

    // MARK: - Sections

    private var storageSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Storage")
                .font(.headline)

            if let volume = viewModel.report?.systemVolume {
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(StorageFormatter.capacity(volume.availableCapacity))
                        .font(.title2.weight(.semibold))
                    Text("(\(StorageFormatter.percentage(volume.availableFraction)))")
                        .foregroundStyle(.secondary)
                }

            } else {
                Text(viewModel.isRefreshing ? "Loading..." : "Unavailable")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.secondary)
            }

            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var diskInformationSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Disk Information")
                .font(.headline)

            if let volume = viewModel.report?.systemVolume {
                StorageInformationRow(
                    title: "Total Capacity",
                    value: StorageFormatter.capacity(volume.totalCapacity)
                )
                StorageInformationRow(
                    title: "Used",
                    value: StorageFormatter.capacity(volume.usedCapacity)
                )
                StorageInformationRow(
                    title: "Available",
                    value: StorageFormatter.capacity(volume.availableCapacity)
                )
                StorageInformationRow(
                    title: "Usage",
                    value: StorageFormatter.percentage(volume.usageFraction)
                )
            } else {
                Text("Storage information is not available.")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var connectedStorageSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Connected Storage")
                .font(.headline)

            if let volumes = viewModel.report?.externalVolumes {
                if volumes.isEmpty {
                    Text("No external storage connected")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(volumes) { volume in
                        ExternalStorageRow(
                            volume: volume,
                            isEjecting: viewModel.isEjecting(volume),
                            onOpen: {
                                viewModel.openVolume(volume)
                            },
                            onEject: {
                                viewModel.ejectVolume(volume)
                            }
                        )
                    }
                }
            } else {
                Text(viewModel.isRefreshing ? "Loading..." : "Storage information is unavailable.")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }

        }
    }

    private var actionsSection: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("Actions")
                .font(.headline)

            MenuActionRow(title: "Open System Disk in Finder") {
                viewModel.openSystemVolume()
            }
            MenuActionRow(title: "Open Disk Utility") {
                SystemNavigation.openDiskUtility()
            }
            MenuActionRow(title: "Open Storage Settings") {
                SystemNavigation.openStorageSettings()
            }
            MenuActionRow(title: "Quit") {
                SystemNavigation.quitApplication()
            }
            .keyboardShortcut("q")

            if let errorMessage = viewModel.volumeActionErrorMessage {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundStyle(.red)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var sectionDivider: some View {
        Divider()
            .padding(.vertical, 11)
    }
}

/// 디스크 정보의 레이블과 값을 한 행에 정렬합니다.
private struct StorageInformationRow: View {
    let title: String
    let value: String

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .foregroundStyle(.secondary)
            Spacer(minLength: 16)
            Text(value)
                .monospacedDigit()
        }
        .font(.callout)
    }
}

/// 연결된 외장 볼륨을 Finder 시스템 아이콘과 함께 표시합니다.
private struct ExternalStorageRow: View {
    let volume: StorageVolume
    let isEjecting: Bool
    let onOpen: () -> Void
    let onEject: () -> Void

    @State private var isOpenAreaHovered = false

    var body: some View {
        HStack(spacing: 6) {
            Button(action: onOpen) {
                HStack(spacing: 9) {
                    Image(nsImage: NSWorkspace.shared.icon(forFile: volume.mountURL.path))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 24, height: 24)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(volume.name)
                            .lineLimit(1)
                        Text(
                            "\(StorageFormatter.capacity(volume.totalCapacity)) total · "
                            + "\(StorageFormatter.capacity(volume.availableCapacity)) available"
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .padding(.vertical, 3)
            .padding(.horizontal, 4)
            .background(.primary.opacity(isOpenAreaHovered ? 0.06 : 0))
            .clipShape(RoundedRectangle(cornerRadius: 5))
            .onHover { isOpenAreaHovered = $0 }
            .disabled(isEjecting)

            if volume.isEjectable {
                Button(action: onEject) {
                    Image(systemName: isEjecting ? "eject.fill" : "eject")
                        .frame(width: 20, height: 20)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .help("Eject \(volume.name)")
                .accessibilityLabel("Eject \(volume.name)")
                .disabled(isEjecting)
            }
        }
    }
}

/// 메뉴 하단의 텍스트 중심 시스템 동작 버튼입니다.
private struct MenuActionRow: View {
    let title: String
    var isDisabled = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(isDisabled)
    }
}
