import Foundation

/// 한 시점에 조회한 마운트 볼륨의 저장공간 정보를 나타냅니다.
struct StorageVolume: Identifiable, Equatable, Sendable {
    let id: URL
    let name: String
    let mountURL: URL
    let totalCapacity: Int64
    let availableCapacity: Int64
    let isEjectable: Bool

    /// 현재 사용 중인 용량입니다.
    var usedCapacity: Int64 {
        max(totalCapacity - availableCapacity, 0)
    }

    /// 전체 용량 중 사용 가능한 용량의 비율입니다.
    var availableFraction: Double {
        guard totalCapacity > 0 else { return 0 }
        return Double(availableCapacity) / Double(totalCapacity)
    }

    /// 전체 용량 중 사용 중인 용량의 비율입니다.
    var usageFraction: Double {
        guard totalCapacity > 0 else { return 0 }
        return Double(usedCapacity) / Double(totalCapacity)
    }
}

/// 시스템 볼륨과 연결된 외장 볼륨을 함께 담은 조회 결과입니다.
struct StorageReport: Equatable, Sendable {
    let systemVolume: StorageVolume
    let externalVolumes: [StorageVolume]
    let refreshedAt: Date
}
