import Foundation
import Observation

/// 메뉴에 표시할 저장공간 상태와 사용자 요청 기반 갱신을 관리합니다.
@MainActor
@Observable
final class YourDiskViewModel {
    private(set) var report: StorageReport?
    private(set) var isRefreshing = false
    private(set) var errorMessage: String?
    private(set) var volumeActionErrorMessage: String?
    private(set) var ejectingVolumeIDs = Set<StorageVolume.ID>()

    @ObservationIgnored
    private let storageService: any StorageVolumeProviding

    @ObservationIgnored
    private let volumeActionService: any VolumeActionProviding

    @ObservationIgnored
    private let volumeObserver = WorkspaceVolumeObserver()

    @ObservationIgnored
    private var refreshPending = false

    /// 지정한 저장공간 서비스를 사용하는 ViewModel을 생성합니다.
    init(
        storageService: any StorageVolumeProviding = SystemStorageService(),
        volumeActionService: any VolumeActionProviding = WorkspaceVolumeActionService()
    ) {
        self.storageService = storageService
        self.volumeActionService = volumeActionService
    }

    // MARK: - Refresh

    /// 메뉴 표시 중 볼륨 변경 알림을 구독하고 현재 정보를 조회합니다.
    func startObservingVolumeChanges() {
        volumeObserver.start { [weak self] in
            self?.refresh()
        }
        refresh()
    }

    /// 메뉴가 닫히면 볼륨 변경 알림 구독을 즉시 해제합니다.
    func stopObservingVolumeChanges() {
        volumeObserver.stop()
        refreshPending = false
        volumeActionErrorMessage = nil
    }

    // MARK: - Volume Actions

    /// Finder에서 선택한 외장 볼륨의 루트 폴더를 엽니다.
    func openVolume(_ volume: StorageVolume) {
        guard !ejectingVolumeIDs.contains(volume.id) else { return }

        volumeActionErrorMessage = nil
        do {
            try volumeActionService.revealVolume(at: volume.mountURL)
        } catch {
            volumeActionErrorMessage = error.localizedDescription
        }
    }

    /// Finder에서 현재 시스템 볼륨의 루트 폴더를 엽니다.
    func openSystemVolume() {
        guard let systemVolume = report?.systemVolume else {
            volumeActionErrorMessage = "System volume information is unavailable."
            return
        }
        openVolume(systemVolume)
    }

    /// 선택한 외장 볼륨을 안전하게 추출하고 목록을 갱신합니다.
    func ejectVolume(_ volume: StorageVolume) {
        guard volume.isEjectable,
              !ejectingVolumeIDs.contains(volume.id) else {
            return
        }

        volumeActionErrorMessage = nil
        ejectingVolumeIDs.insert(volume.id)

        Task { [weak self, volumeActionService] in
            do {
                try await volumeActionService.ejectVolume(at: volume.mountURL)
                guard let self else { return }
                self.ejectingVolumeIDs.remove(volume.id)
                self.refresh()
            } catch {
                guard let self else { return }
                self.ejectingVolumeIDs.remove(volume.id)
                self.volumeActionErrorMessage = "Could not eject \(volume.name): "
                    + error.localizedDescription
            }
        }
    }

    /// 지정한 볼륨이 현재 안전 추출 처리 중인지 반환합니다.
    func isEjecting(_ volume: StorageVolume) -> Bool {
        ejectingVolumeIDs.contains(volume.id)
    }

    /// 사용자 동작으로 요청된 경우에만 최신 저장공간 정보를 조회합니다.
    func refresh() {
        guard !isRefreshing else {
            refreshPending = true
            return
        }

        isRefreshing = true
        errorMessage = nil

        Task { [weak self, storageService] in
            do {
                let report = try await storageService.fetchStorageReport()
                guard let self else { return }
                self.report = report
                self.finishRefresh()
            } catch {
                guard let self else { return }
                self.errorMessage = error.localizedDescription
                self.finishRefresh()
            }
        }
    }

    /// 현재 조회를 마치고 대기 중인 이벤트가 있으면 한 번 더 갱신합니다.
    private func finishRefresh() {
        isRefreshing = false

        guard refreshPending else { return }
        refreshPending = false
        refresh()
    }
}
